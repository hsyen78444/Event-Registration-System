package ca.mcgill.ecse321.eventregistration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventregistrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
